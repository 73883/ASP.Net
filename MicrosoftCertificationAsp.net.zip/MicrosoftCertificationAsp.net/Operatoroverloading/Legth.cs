﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace Operatoroverloading
{
    internal class Legth

    { public int length;
       
        public Legth()
        {

        }
        public Legth(int length) {
            this.length = length;
        }
        public static Legth operator+ ( Legth left, Legth right )
        {
            Legth l= new Legth();
            l.length = left.length+right.length;
            return l;
        }
        static void Main(string[] args)
        {
            Legth l1 = new Legth(10);
            Legth l2 = new Legth(10);
            Legth l3 = l1 + l2;
            Console.WriteLine(l3.length);
            Console.ReadLine();
        }
    }
}
