//instance of web application builder
using Con_Middleware;

var builder = WebApplication.CreateBuilder(args);

//Instance od web application
var app = builder.Build();


//middle ware 1  by using app.Use() method
app.Use( async (HttpContext context, RequestDelegate next) =>
    {
        //logic before next
       await context.Response.WriteAsync("from middleware 1");
        //passing to next middleware
       await  next(context);
       //logic after next
        await context.Response.WriteAsync("from middleware 1");

    });

//middlware 2 by using app.use() method
app.Use(async (HttpContext context, RequestDelegate next) =>
{
    //logic before next
    await context.Response.WriteAsync("from middleware 2");
    //passing to next middleware
    await next(context);
    //logic after next
    await context.Response.WriteAsync("from middleware 2");

});

//middleware extension for middleware created by conventional method
//used template for conventional custom middleware

//middleware 3
app.UseConventionalmiddleware();

//middleware 4
app.Run(async(HttpContext context) =>
{  
    //logic before next
    await context.Response.WriteAsync(" Treminating middleware started");

    //logic while returning back to middleware 1
    await context.Response.WriteAsync(" Treminating middleware ended ");
});



app.Run();
