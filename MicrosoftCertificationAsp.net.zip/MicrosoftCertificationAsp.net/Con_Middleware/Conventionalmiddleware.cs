﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace Con_Middleware
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class Conventionalmiddleware
    {
        private readonly RequestDelegate _next;

        public Conventionalmiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async   Task  Invoke(HttpContext httpContext)
        {
            //logic before next
            await httpContext.Response.WriteAsync("from conventional middleware 3 started");
            //pasing to next middleware
            await _next(httpContext);
            //logic after next
            await httpContext.Response.WriteAsync("from conventional middleware 3 ended ");

        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class ConventionalmiddlewareExtensions
    {
        public static IApplicationBuilder UseConventionalmiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<Conventionalmiddleware>();
        }
    }
}
