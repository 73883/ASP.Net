﻿using Microsoft.AspNetCore.Mvc;


namespace Basiccontroller.Controllers
{
    public class HomeController 
    {
        //add routing value fot this controller
        [Route("Home")]
        public String Index()
        {
            return  "welcome to home controller";
        }
    }
}
