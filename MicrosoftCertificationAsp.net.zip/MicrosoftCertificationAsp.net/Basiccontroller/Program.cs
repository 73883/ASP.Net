var builder = WebApplication.CreateBuilder(args);
//adding all controllers in one shot 
builder.Services.AddControllers();
var app = builder.Build();

//map all controllers in one shot 
app.MapControllers();



app.Run();
