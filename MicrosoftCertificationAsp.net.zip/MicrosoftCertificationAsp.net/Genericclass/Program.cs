﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Genericclass
{    
    //generic class
    /*internal class Program<T>
    {
        public T data;
        static void Main(string[] args)
        {
            Program<int> p = new Program<int>();
            p.data = 10;

            Program<String> p2 = new Program<String>();
            p2.data = "ashutosh";
        }
    }*/

    //generic method
    public class Program <T,t>
    {
        public String addmethod(T a ,t b)
        {
            return ("two provided qauntity are a="+a+"b="+b) ;
        }

        public T printval(T a)
        {
            return a ;
        }
        static void Main(string[] args)
        {
            Program<int , String > p = new Program<int,String>();
            p.addmethod(10, "ashutosh");
            p.printval(10);
            //p.printval("ashutosh");
            

       
        }
    }
}
