﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Indexers
{
public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string FirstName { get; set; }
        public int age { get; set; }

        public Employee(int ID, String Name, String FirstName, int age)
        {
            this.Id = ID;
            this.Name = Name;
            this.FirstName = FirstName;
            this.age = age;

        }

        //creating indexers
        public object this[int index]
        {
            get
            {
                if (index == 0)
                { return Id; }
                else
                    return null;
            }
            set
            {
                if (index == 0)
                {
                    Id = (int)value;
                }
            }

        }



    }
   public class Program
    {
        static void Main(string[] args)

        {
            Employee employee = new Employee(1,"araut","ashutosh",24) ;
             int id= (int)employee[0];
            Console.WriteLine(id);

        
        }
    }
}
