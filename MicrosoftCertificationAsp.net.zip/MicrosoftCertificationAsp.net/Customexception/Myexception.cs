﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customexception
{
    internal class Myexception : Exception
    {
        public Myexception(String message):base(message) {

        }

    }
}
