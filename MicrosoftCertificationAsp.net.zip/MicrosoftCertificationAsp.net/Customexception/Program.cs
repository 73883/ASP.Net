﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customexception
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                String s;
                Console.WriteLine("Enter your name");
               s= Console.ReadLine();
                if (s.Length>5)
                {
                    throw new  Myexception("name should be less than 5");
                }
                else
                {
                    Console.WriteLine("Valid name");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
