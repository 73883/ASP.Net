﻿using Microsoft.AspNetCore.Mvc;

namespace Fileresult.Controllers
{
    public class HomeController : Controller
    { 
        //if file is present wwwroot
        [Route("/virtual")]
        public VirtualFileResult Index1()
        {
            return File("/resume.pdf","application/pdf");
        }


        //physical file result if file present outside project 
        [Route("/physical")]
        public PhysicalFileResult Index2()
        {
            return PhysicalFile("C:\\Users\\Ashitosh\\Downloads\\Ashitosh_Resume.pdf", "application /pdf"); 
        }

        //if file content is byte[] and we want to return it 
        [Route("/byte")]
        public FileContentResult Index3()

        {
            //creating byte array
            byte[] bytes = System.IO.File.ReadAllBytes(@"C:\\Users\\Ashitosh\\Downloads\\Ashitosh_Resume.pdf");
            return File(bytes, "application /pdf");
        }

    }
}
