﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Mime;

namespace Contentresult.Controllers
{
   public class HomeController : Controller
    {
        [Route("Home")]
        public ContentResult Index()
        {
            return Content("Welcome to standard wy of return result", "text/plain");
        }
    }


    //or but not prefred

   /* public class HomeController
    {
        [Route("/Home")]
        public ContentResult Index() { 

            return new ContentResult(
                 Content="welcome",
                 ContentType= "text/plain"

                
                );
        
        }
    }*/
}
