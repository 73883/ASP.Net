var builder = WebApplication.CreateBuilder(args);
//adding controller
builder.Services.AddControllers();
var app = builder.Build();

//mapping controllers
app.MapControllers();



app.Run();
