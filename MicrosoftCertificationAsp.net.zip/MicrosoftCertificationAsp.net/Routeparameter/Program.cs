var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

//enable routing
app.UseRouting();
app.UseEndpoints(endpoints =>
{    
    //both id and name is required
    endpoints.MapGet("/product/{id}/{name}", async (HttpContext context) =>
    {
        var id = context.Request.RouteValues["id"];
        var name = context.Request.RouteValues["name"];
        await context.Response.WriteAsync($"Book has id {id} and book name is {name} ");

    });

    // if i want to assign any default value for any parametr 
    endpoints.MapGet("/products/{id}/{name='ashutosh'}", async (HttpContext context) =>
    {
        var id = context.Request.RouteValues["id"];
        var name = context.Request.RouteValues["name"];
        await context.Response.WriteAsync($"Book has id {id} and book name is {name} ");

    });

    //if i want to make any paramter as optional

    
    endpoints.MapGet("/products/{id?}/{name='ashutosh'}", async (HttpContext context) =>
    {
        var id = context.Request.RouteValues["id"];
        var name = context.Request.RouteValues["name"];
        await context.Response.WriteAsync($"Book has id {id} and book name is {name} ");

    });



}
);

app.Run();
