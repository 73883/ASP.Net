﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Gendelegate
{
    internal class Program
    {
        public int fundelexample(int x, int y, int z)
        {
            return x + y + z;
        }
        public void actiondel(int x, int y, int z)
        {
            int c = x + y + z;
            Console.WriteLine("sum is=" + c);
        }
        public bool predicatedel ( String a )  //predicate only takes one parameter 
        {
            return a.Equals("ashutosh");
        }

        static void Main(string[] args)
        {
           Program p = new Program();
            Func<int, int, int, int> d = p.fundelexample;  // forth int is for return type 
          int sum=  d.Invoke(10, 20, 30);
            Console.WriteLine(sum);

            Action<int, int, int> d2= p.actiondel;
            d2.Invoke(10, 20, 30);

            Predicate<String > d3= p.predicatedel;  // no need to metntion return type here 
            bool ans3=d3.Invoke("ashutosh");
            Console.WriteLine(ans3);


        }
    }
}
