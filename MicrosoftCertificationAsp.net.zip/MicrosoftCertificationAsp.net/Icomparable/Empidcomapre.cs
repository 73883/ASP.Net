﻿namespace Icomparable
{
    public class Empidcomapre : IComparable<Empidcomapre>
    {

        public int empid { get; set; }
       public  Empidcomapre( int empid) {
            this.empid = empid;
                }

        public static void main(string[] args)
        {
            Empidcomapre e1= new Empidcomapre(10);
            Empidcomapre e2 = new Empidcomapre(20);
           int result= e1.CompareTo(e2);
            Console.WriteLine(result);
        }

        
        public int CompareTo(Empidcomapre other)
        {
            return this.empid.CompareTo(other.empid);

        }
    }
}
