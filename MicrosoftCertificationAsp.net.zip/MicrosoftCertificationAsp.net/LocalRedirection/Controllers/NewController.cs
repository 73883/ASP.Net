﻿using Microsoft.AspNetCore.Mvc;

namespace LocalRedirection.Controllers
{
    public class NewController : Controller
    {
        [Route("/new")]
        public IActionResult Oldmethod()
        {
            return Content("You are redirect to new controller", "text/plain");
        }
    }
}
