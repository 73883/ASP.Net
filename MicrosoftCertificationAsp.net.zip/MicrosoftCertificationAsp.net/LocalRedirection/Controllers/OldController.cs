﻿using Microsoft.AspNetCore.Mvc;

namespace LocalRedirection.Controllers
{
    public class OldController : Controller
    {
        [Route("/old")]
        public IActionResult Oldmethod()
        {
            //temperory redirection
            // return new  RedirectToActionResult("Oldmethod","New", new {});
            // return RedirectToAction("Oldmethod","New", new {});
            // return new LocalRedirectResult("/new");
            //return  LocalRedirect("/new");


            //permanent redirection
            //return new RedirectToActionResult("Oldmethod", "New", new { },true);

           // return RedirectToAction("Oldmethod", "New", new { });
             return new LocalRedirectResult("/new",true);


        }
    }
}
