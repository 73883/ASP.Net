﻿using Jsonresult.Model;
using Microsoft.AspNetCore.Mvc;

namespace Jsonresult.Controllers
{
    public class HomeController : Controller
    {
        [Route("/emp")]
        public JsonResult Index()
        {
           Employee employee = new Employee() { Id=1,Name="ashutosh",Salary=40000,Age=24};
            return Json(employee);
        }
    }
}
