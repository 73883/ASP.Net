﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptioncode1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            try
            {
                int x, y;
                Console.WriteLine("Enter  numer1");
              x=Convert.ToInt32( Console.ReadLine());
                Console.WriteLine("Enter  numer2");
                y = Convert.ToInt32(Console.ReadLine());
                if (y==0)
                {
                    throw new DivideByZeroException("cannot divide by zero");
                }
                else
                {
                    Console.WriteLine("division=" + (x / y));
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                Console.WriteLine("Successfully exited");
            }
        }
    }
}
