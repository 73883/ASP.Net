﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegate
{
    internal class Program

    { public  delegate int  addnumdel (int x, int y);
        public delegate string retunnamedel(string s);
 


        public int addtwonum( int a , int b )
        {
            return a + b;
        }
        public String returnname( String s)
        {
            return s;
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            //Creating instance of delegate 
            addnumdel add = new addnumdel(p.addtwonum);
            retunnamedel name = new retunnamedel(p.returnname);
            //invoke delegate 
          int sum=  add.Invoke(100, 200);
           string myname = name.Invoke("ashutosh");
            Console.WriteLine(myname);
            Console.WriteLine(sum);
            Console.ReadLine();



        }
    }
}
