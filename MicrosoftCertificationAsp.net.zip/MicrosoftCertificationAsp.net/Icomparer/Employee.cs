﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icomparer
{
    internal class Employee

    {
        public int id;
        public string name;
        public int age; 
        public Employee( int id, String name ,int age ) { }
        static void Main(string[] args)
        {
            List<Employee> list = new List<Employee>() { new Employee(1,"ashutosh",12),
                                                          new Employee(2,"shrinath",22),
                                                          new Employee(3,"pratiksha",34)

            };
            list.Sort(new Agecompare());
        }
    }
}
