﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icomparer
{
    internal class Agecompare : IComparer<Employee>
    {
        public int Compare(Employee x, Employee y)
        {
            return x.age.CompareTo(y.age);
        }
    }
}
