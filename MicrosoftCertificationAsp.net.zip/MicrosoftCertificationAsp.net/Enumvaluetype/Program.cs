﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enumvaluetype

{
    public enum days
    {
        sun,mon,tue,wed,thur,fri,sat
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine((int)days.wed);
            Console.ReadLine();
        }
    }
}
