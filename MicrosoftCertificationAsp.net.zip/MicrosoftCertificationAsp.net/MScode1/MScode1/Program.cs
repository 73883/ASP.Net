using System.Security.Cryptography;
using System.Xml.Linq;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.Run( async (HttpContext context) => { 
    var path=context.Request.Path;
    var method=context.Request.Method;
    if (method=="get" && path == "/"|| path =="/home")
    {
        context.Response.StatusCode = 200;
      await context.Response.WriteAsync("you are in home page");
    }
    else if (method=="Post" &&path=="/products")
    {
        /* if (context.Request.Query.ContainsKey("id") && context.Request.Query.ContainsKey("name"))
         {  
             String id = context.Request.Query["id"];
             String name= context.Request.Query["name"];
             context.Response.StatusCode = 200;
            await    context.Response.WriteAsync("you have selected product id=" + id + "name=" + name);
         }
         else
         {
             context.Response.StatusCode = 404;
            await context.Response.WriteAsync("produt not found");
         }*/
        String value = "";
        StreamReader streamReader = new StreamReader(context.Request.Body); //body is in stream
        String data=streamReader.ReadToEnd();
        context.Response.WriteAsync("data from postman" + data);
    }
    else
    {
        context.Response.StatusCode = 400;
       await context.Response.WriteAsync("page not found");
    }


});

app.Run();
