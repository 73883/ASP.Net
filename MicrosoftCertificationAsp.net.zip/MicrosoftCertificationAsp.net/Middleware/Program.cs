// creating instance of web application builder
using Middleware.Custom_Middleware;

var builder = WebApplication.CreateBuilder(args);

//registering custom middleware 
builder.Services.AddTransient<Mymiddleware>();

//creating instance of web application
var app = builder.Build();

//Middleware 1
app.Use(async (HttpContext context, RequestDelegate next) =>
    {
        //manipulating data by using context
       await context.Response.WriteAsync("data manipulated by middleware1");    //******1
        //as we have manipulated context so we need to pass new context
         await next(context);
        //after this line it moves to next middleware

        await context.Response.WriteAsync("***********code after next is executed when browser takes back to app.use at end in middlware 111");//****5=

    });
//middleware 2
app.Use(async (HttpContext context, RequestDelegate next) =>
{
    //manipulating data by using context
    await context.Response.WriteAsync("data manipulated by middleware2");  //*******2
    //as we have manipulated context so we need to pass new context
    await next(context);
    //after this line it moves to next middleware

    await context.Response.WriteAsync("***********code after next is executed when browser takes back to app.use at end in middlware 222");//***4

});

//middleware 3 custom middleware
//app.UseMiddleware<Mymiddleware>();

// i want to access custom middleware like app.mymiddleware()
//so i neeed to create custom extension
app.middlewareextension();

//terminating middleware
app.Run(async (HttpContext context )=>
{
    await context.Response.WriteAsync("Data from terminating middleware");    //******3
});

app.Run();
