﻿namespace Middleware.Custom_Middleware
{
    public class Mymiddleware : IMiddleware
    {
        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            //Before next logic
            await context.Response.WriteAsync("Custom code startted");
            await context.Response.WriteAsync("/n");
            //next 
            await next(context);

            //after next logic while returning cursor
            await context.Response.WriteAsync("Custom code finished");
            await context.Response.WriteAsync("/n");




        }
    }

    // step 2 create custom extension


    public static class Customextension
        {

          public static IApplicationBuilder middlewareextension( this IApplicationBuilder app)
        {
            return app.UseMiddleware<Mymiddleware>();
        }
        }


}
