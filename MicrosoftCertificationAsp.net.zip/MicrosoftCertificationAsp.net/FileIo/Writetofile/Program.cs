﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Writetofile
{
    internal  class Program
    { String filepath = @"D:\\FileIo\\Mytext.txt";
        String line = "this is first line in code";
        String[] s = { "ashutosh", "shrinath", "akshat" };
        String r;
        String[] R;
        public void adddata()
        {
            if (File.Exists(filepath))
            {
                File.WriteAllText(filepath, line);
                File.AppendAllLines(filepath, s);
            }

        }
        public void readalltext()
        { 
            if (File.Exists(filepath))
            {
               r= File.ReadAllText(filepath);
              Console.WriteLine(r);
            }

        }
        public void readallline()
        {
            if(File.Exists(filepath))
            {
                  R= File.ReadAllLines(filepath);
                foreach (String s in R)
                {
                   Console.WriteLine (s);
                }
            }
        }
        static void Main(string[] args)
        { 
           Program p = new Program();
            p.adddata();
            p.readalltext();
            p.readallline();
        }
    }
}
