

using Customrouteconstraints.customroutes;

var builder = WebApplication.CreateBuilder(args);

//registering custom regex class
builder.Services.AddRouting(options=>
{
    options.ConstraintMap.Add("alphanumeric", typeof(Mycustomroute));
    options.ConstraintMap.Add("Datevalidation", typeof(Validdate));
}
    );
var app = builder.Build();



//Check valid alphanumeric username 
app.UseRouting();
app.UseEndpoints(endpoints =>
{
    endpoints.MapGet("/users/{username:alphanumeric}", async (HttpContext context) =>
    {
        String username = Convert.ToString(context.Request.RouteValues["username"]);
        context.Response.WriteAsync($"user with username {username} is logged");
    });

    endpoints.MapGet("/userdob/{dob:Datevalidation}", async (HttpContext context) =>
    {
        String date = Convert.ToString(context.Request.RouteValues["dob"]);
        context.Response.WriteAsync($" user date of birth is{date}");

    });
});


//check valid date format 

app.Run();
