﻿using System.Text.RegularExpressions;

namespace Customrouteconstraints.customroutes
{
    public class Validdate : IRouteConstraint
    {
        public bool Match(HttpContext? httpContext, 
            IRouter? route, string routeKey, 
            RouteValueDictionary values, 
            RouteDirection routeDirection)
        {
            if(!values.ContainsKey(routeKey))
            {
                return false;
            }
            else
            {
                Regex regx = new Regex("^(0[1-9]|1[0-2])-(0[1-9]|1\\d|2\\d|3[01])-\\d{4}$\r\n");
                String date =Convert.ToString( values[routeKey]);
                if (regx.IsMatch(date))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
