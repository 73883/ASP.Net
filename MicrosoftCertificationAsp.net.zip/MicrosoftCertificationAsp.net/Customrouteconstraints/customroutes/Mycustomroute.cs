﻿using System.Text.RegularExpressions;

namespace Customrouteconstraints.customroutes
{
    public class Mycustomroute : IRouteConstraint
    {
        public bool Match(HttpContext? httpContext, 
            IRouter? route, 
            string routeKey, 
            RouteValueDictionary values,
            RouteDirection routeDirection)
        {
           if (!values.ContainsKey(routeKey))
            {
                return false;
            }
            else
            {
                Regex regx = new Regex("^[a-zA-z0-9]+$");
                String username = Convert.ToString(values[routeKey]);
                if(regx.IsMatch(username))
                {
                    return true;
                }
                return false;
            }
        }
    }
}
