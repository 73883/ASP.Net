﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace Multicastdel
{
    public delegate int Mydelegate(int x, int y);
    internal class Program
    {  //defining delegate
 


        public int addnum(int x, int y)
        {
            return x+y;
        }
        public int subnum(int x, int y)
        {
            return x - y;
        }
        public int mulnum(int x, int y)
        {
            return x * y;
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            Mydelegate mydelegate = p.addnum;
            mydelegate += p.mulnum;
            mydelegate += p.subnum;
            int ans=mydelegate.Invoke(400, 200);
            Console.WriteLine(ans);
        }
    }
}
