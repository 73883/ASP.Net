﻿using Microsoft.AspNetCore.Mvc;

namespace Statuscode.Controllers
{
    public class BookController : Controller
    {
        //Book?islogged=true&bookid=100
        [Route("/Book")]
        
        public IActionResult Index()
        {   
            //check id bookid key is present in query string
            if(!Request.Query.ContainsKey("bookid")) { 
            
                return BadRequest("Bookid is not present in query string");
            }

            //check if bookid between 1 and 1000 is present in query string
            int bookid = Convert.ToInt32(Request.Query["bookid"]);
            if(!(bookid > 1&& bookid<1000)) { 
              return NotFound("Bookid is not present");
            }

            //check if user is logged in
            Boolean key = Request.Query.ContainsKey("islogged");
            //chekc value of is looged is true or false
            Boolean value = Convert.ToBoolean(Request.Query["islogged"]);
            if (!(key&&value))
            {
                return new UnauthorizedResult();
            }
            else
            {
                return PhysicalFile("C:\\Users\\Ashitosh\\Downloads\\Ashitosh_Resume.pdf", "application /pdf");
            }

        }
    }
}
