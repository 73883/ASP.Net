//creating instance of webapplication builder
var builder = WebApplication.CreateBuilder(args);

//creating instance of webapplication
var app = builder.Build();

//not a proper way to handle route
//app.MapGet("/", () => "Hello World!");

//enable routing
app.UseRouting();

app.UseEndpoints(endpoints =>
{
    endpoints.Map("/homes", async (HttpContext context) =>
    await context.Response.WriteAsync("you are in map home page"));




    endpoints.MapGet("/home", async (HttpContext context) =>
    await context.Response.WriteAsync("you are in mapget home page"));



    endpoints.MapPost("/home", async (HttpContext context) =>
    await context.Response.WriteAsync("produxt added successfully"));

});

app.Run(async (HttpContext context) =>
{
await context.Response.WriteAsync("page not found");
});





app.Run();
