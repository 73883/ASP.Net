using Microsoft.Extensions.FileProviders;

var builder = WebApplication.CreateBuilder(new WebApplicationOptions()
{
    WebRootPath = "staticfile"  // added as default static file path 
}) ;
var app = builder.Build();
//adding multiple static file folder
app.UseStaticFiles(new StaticFileOptions()
{
    FileProvider = new PhysicalFileProvider(Path.Combine(builder.Environment.ContentRootPath,"secstatic"))
}) ;

app.MapGet("/", () => "Hello World!");

app.Run();
